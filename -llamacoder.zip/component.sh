#!/bin/bash

# Script pour créer un nouveau composant React

# Vérifier si un nom de composant est fourni
if [ -z "$1" ]; then
    echo "Usage: ./component.sh <NomDuComposant>"
    exit 1
fi

COMPONENT_NAME=$1
COMPONENT_DIR="src/components/$COMPONENT_NAME"

# Créer le dossier du composant
mkdir -p "$COMPONENT_DIR"

# Créer le fichier principal du composant
cat > "$COMPONENT_DIR/$COMPONENT_NAME.tsx" << EOF
import React from 'react';
import { cn } from '@/lib/utils';

interface ${COMPONENT_NAME}Props {
  className?: string;
}

export function ${COMPONENT_NAME}({ className }: ${COMPONENT_NAME}Props) {
  return (
    <div className={cn("", className)}>
      {/* Contenu du composant */}
    </div>
  );
}
EOF

# Créer le fichier de styles (si nécessaire)
cat > "$COMPONENT_DIR/$COMPONENT_NAME.css" << EOF
/* Styles pour $COMPONENT_NAME */
EOF

# Créer le fichier de test (optionnel)
cat > "$COMPONENT_DIR/$COMPONENT_NAME.test.tsx" << EOF
import { render, screen } from '@testing-library/react';
import { ${COMPONENT_NAME} } from './${COMPONENT_NAME}';

describe('${COMPONENT_NAME}', () => {
  it('renders correctly', () => {
    render(<${COMPONENT_NAME} />);
    expect(screen.getByRole('div')).toBeInTheDocument();
  });
});
EOF

# Créer le fichier d'index pour faciliter les exports
cat > "$COMPONENT_DIR/index.ts" << EOF
export { ${COMPONENT_NAME} } from './${COMPONENT_NAME}';
EOF

echo "✅ Composant $COMPONENT_NAME créé avec succès dans $COMPONENT_DIR"