# Rendre le script exécutable
chmod +x component.sh

# Créer un composant
./component.sh MonNouveauComposant