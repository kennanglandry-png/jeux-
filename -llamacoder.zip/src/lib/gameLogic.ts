// Logique pure du jeu de Pêche

import type {
  Card,
  CardColor,
  CardValue,
  GameState,
  Player,
  Person,
  Direction,
} from "@/types/game";

export const COLORS: CardColor[] = ["Trèfle", "Carreau", "Cœur", "Pique"];
export const VALUES: CardValue[] = [
  "As",
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  "10",
  "Valet",
  "Dame",
  "Roi",
];

export const COLOR_SYMBOL: Record<CardColor, string> = {
  Trèfle: "♣",
  Carreau: "♦",
  Cœur: "♥",
  Pique: "♠",
};

export const COLOR_IS_RED: Record<CardColor, boolean> = {
  Trèfle: false,
  Carreau: true,
  Cœur: true,
  Pique: false,
};

let idCounter = 0;
function nextId(prefix: string): string {
  idCounter += 1;
  return `${prefix}-${idCounter}`;
}

export function createCard(value: CardValue, color: CardColor): Card {
  return {
    id: nextId("card"),
    value,
    color,
    name: `${value} de ${color}`,
  };
}

// Paire de 52 cartes : toutes les combinaisons simples possibles
export function createCardPair(): Card[] {
  const deck: Card[] = [];
  for (const color of COLORS) {
    for (const value of VALUES) {
      deck.push(createCard(value, color));
    }
  }
  return deck;
}

export function shuffle<T>(array: T[]): T[] {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export function cardPoints(card: Card): number {
  if (card.value === "As") return 11;
  if (card.value === "Valet" || card.value === "Dame" || card.value === "Roi")
    return 2;
  return parseInt(card.value, 10);
}

export function handPoints(hand: Card[]): number {
  return hand.reduce((sum, c) => sum + cardPoints(c), 0);
}

export function canPlayCard(
  card: Card,
  topCard: Card | null,
  activeColor: CardColor | null
): boolean {
  if (!topCard) return true;
  // Le Valet peut être déposé sur n'importe quoi sauf sur un 2
  if (card.value === "Valet") {
    return topCard.value !== "2";
  }
  const effectiveColor = activeColor ?? topCard.color;
  return card.color === effectiveColor || card.value === topCard.value;
}

export function createPlayers(count: number): Player[] {
  const names: [string, string][] = [
    ["Alice", "Martin"],
    ["Bob", "Durand"],
    ["Chloé", "Bernard"],
    ["David", "Petit"],
  ];
  const players: Player[] = [];
  for (let i = 0; i < count; i++) {
    const person: Person = {
      id: nextId("person"),
      firstName: names[i][0],
      lastName: names[i][1],
    };
    players.push({
      person,
      hand: [],
      isHuman: i === 0, // Le joueur 0 est l'humain
      score: 0,
    });
  }
  return players;
}

export function initGame(playerCount: number, cardsPerPlayer: number): GameState {
  const deck = shuffle(createCardPair());
  const players = createPlayers(playerCount);

  let index = 0;
  for (let c = 0; c < cardsPerPlayer; c++) {
    for (let p = 0; p < playerCount; p++) {
      players[p].hand.push(deck[index++]);
    }
  }

  const drawStack = deck.slice(index);
  const firstPlayer = Math.floor(Math.random() * playerCount);

  return {
    players,
    drawStack,
    depositStack: [],
    currentPlayerIndex: firstPlayer,
    direction: "horaire",
    pendingDraw: 0,
    skipNext: false,
    activeColor: null,
    winner: null,
    log: [
      {
        id: nextId("log"),
        message: `Partie lancée avec ${playerCount} joueurs (${cardsPerPlayer} cartes chacun).`,
        type: "system",
      },
      {
        id: nextId("log"),
        message: `${players[firstPlayer].person.firstName} commence la partie.`,
        type: "info",
      },
    ],
    gameOver: false,
    awaitingColorChoice: false,
  };
}

export function nextPlayerIndex(state: GameState): number {
  const step = state.direction === "horaire" ? 1 : -1;
  const n = state.players.length;
  return (state.currentPlayerIndex + step + n) % n;
}

// Stratégie IA : minimiser les points, bloquer un joueur à 1 carte
export function chooseAICard(state: GameState, player: Player): Card | null {
  const topCard = state.depositStack[state.depositStack.length - 1] ?? null;
  const playable = player.hand.filter((c) =>
    canPlayCard(c, topCard, state.activeColor)
  );
  if (playable.length === 0) return null;

  // Un adversaire n'a plus qu'une carte : essayer de le bloquer
  const threatIndex = state.players.findIndex(
    (p, i) => i !== state.currentPlayerIndex && p.hand.length === 1
  );

  if (threatIndex !== -1) {
    // Priorité aux cartes d'attaque (2, As, 10) pour gêner
    const attack = playable.find(
      (c) => c.value === "2" || c.value === "As" || c.value === "10"
    );
    if (attack) return attack;
  }

  // Sinon, jouer la carte qui rapporte le plus de points (pour s'en débarrasser)
  return playable.sort((a, b) => cardPoints(b) - cardPoints(a))[0];
}