import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card as UICard, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PlayingCard } from "@/components/PlayingCard";
import {
  initGame,
  canPlayCard,
  nextPlayerIndex,
  chooseAICard,
  shuffle,
  handPoints,
  COLOR_SYMBOL,
  COLORS,
} from "@/lib/gameLogic";
import type { Card, CardColor, GameState, LogEntry } from "@/types/game";
import { cn } from "@/lib/utils";

let logId = 0;
function makeLog(message: string, type: LogEntry["type"]): LogEntry {
  logId += 1;
  return { id: `log-${logId}`, message, type };
}

export function GameTable() {
  const [state, setState] = useState<GameState>(() => initGame(3, 5));
  const [selectedColor, setSelectedColor] = useState<CardColor | null>(null);
  const timerRef = useRef<number | null>(null);

  const human = state.players[0];
  const topCard = state.depositStack[state.depositStack.length - 1] ?? null;
  const currentPlayer = state.players[state.currentPlayerIndex];

  // Boucle automatique pour les joueurs IA
  useEffect(() => {
    if (state.gameOver || state.awaitingColorChoice) return;
    if (currentPlayer.isHuman) return;

    timerRef.current = window.setTimeout(() => {
      playAITurn();
    }, 1100);

    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  function addLog(s: GameState, message: string, type: LogEntry["type"]) {
    s.log = [...s.log, makeLog(message, type)];
  }

  function advanceTurn(s: GameState) {
    if (s.skipNext) {
      s.skipNext = false;
      const skipped = nextPlayerIndex(s);
      addLog(
        s,
        `${s.players[skipped].person.firstName} passe son tour (As).`,
        "info"
      );
      s.currentPlayerIndex = skipped;
    }
    s.currentPlayerIndex = nextPlayerIndex(s);
  }

  function applyPendingDraw(s: GameState) {
    if (s.pendingDraw > 0) {
      const victimIndex = nextPlayerIndex(s);
      const victim = s.players[victimIndex];
      const drawn: Card[] = [];
      for (let i = 0; i < s.pendingDraw; i++) {
        if (s.drawStack.length === 0) recycleDrawStack(s);
        if (s.drawStack.length === 0) break;
        drawn.push(s.drawStack.pop()!);
      }
      victim.hand.push(...drawn);
      addLog(
        s,
        `${victim.person.firstName} pioche ${drawn.length} carte(s) (attaque 2).`,
        "attack"
      );
      s.pendingDraw = 0;
      s.skipNext = true;
    }
  }

  function recycleDrawStack(s: GameState) {
    if (s.depositStack.length <= 1) return;
    const top = s.depositStack.pop()!;
    s.drawStack = shuffle(s.depositStack);
    s.depositStack = [top];
    addLog(s, "Pile de pioche épuisée : le dépôt est mélangé et réutilisé.", "system");
  }

  function checkWin(s: GameState): boolean {
    const winner = s.players.find((p) => p.hand.length === 0);
    if (winner) {
      s.winner = winner;
      s.gameOver = true;
      s.players.forEach((p) => (p.score = handPoints(p.hand)));
      addLog(
        s,
        `🏆 ${winner.person.firstName} ${winner.person.lastName} termine ses cartes et gagne !`,
        "win"
      );
      return true;
    }
    return false;
  }

  function playCard(s: GameState, playerIndex: number, card: Card, chosenColor?: CardColor) {
    const player = s.players[playerIndex];
    player.hand = player.hand.filter((c) => c.id !== card.id);
    s.depositStack.push(card);
    s.activeColor = null;

    addLog(
      s,
      `${player.person.firstName} joue : ${card.name}.`,
      "play"
    );

    if (checkWin(s)) return;

    // Effets des cartes
    if (card.value === "Valet") {
      s.activeColor = chosenColor ?? COLORS[Math.floor(Math.random() * 4)];
      addLog(s, `Valet : la couleur devient ${s.activeColor}.`, "info");
    } else if (card.value === "As") {
      s.skipNext = true;
    } else if (card.value === "10") {
      s.direction = s.direction === "horaire" ? "anti-horaire" : "horaire";
      addLog(s, `10 : sens du jeu inversé (${s.direction}).`, "info");
    } else if (card.value === "2") {
      s.pendingDraw = s.pendingDraw === 0 ? 2 : s.pendingDraw * 2;
      addLog(s, `2 posé : attaque de ${s.pendingDraw} cartes.`, "attack");
    }

    applyPendingDraw(s);
    if (s.gameOver) return;
    advanceTurn(s);
  }

  function drawForPlayer(s: GameState, playerIndex: number) {
    if (s.drawStack.length === 0) recycleDrawStack(s);
    if (s.drawStack.length === 0) {
      addLog(s, "Plus aucune carte à piocher.", "system");
      advanceTurn(s);
      return;
    }
    const card = s.drawStack.pop()!;
    s.players[playerIndex].hand.push(card);
    addLog(
      s,
      `${s.players[playerIndex].person.firstName} pioche une carte.`,
      "draw"
    );
    advanceTurn(s);
  }

  function playAITurn() {
    setState((prev) => {
      const s: GameState = structuredClone(prev);
      const player = s.players[s.currentPlayerIndex];
      const card = chooseAICard(s, player);
      if (card) {
        playCard(s, s.currentPlayerIndex, card);
      } else {
        drawForPlayer(s, s.currentPlayerIndex);
      }
      return s;
    });
  }

  function handleHumanPlay(card: Card) {
    if (state.gameOver || currentPlayer.isHuman === false) return;
    if (!canPlayCard(card, topCard, state.activeColor)) return;

    if (card.value === "Valet") {
      setState((prev) => {
        const s: GameState = structuredClone(prev);
        s.awaitingColorChoice = true;
        return s;
      });
      setSelectedColor(null);
      // On stocke la carte choisie via closure
      pendingCardRef.current = card;
      return;
    }

    setState((prev) => {
      const s: GameState = structuredClone(prev);
      playCard(s, 0, card);
      return s;
    });
  }

  const pendingCardRef = useRef<Card | null>(null);

  function confirmColor(color: CardColor) {
    setSelectedColor(color);
    setState((prev) => {
      const s: GameState = structuredClone(prev);
      s.awaitingColorChoice = false;
      if (pendingCardRef.current) {
        playCard(s, 0, pendingCardRef.current, color);
        pendingCardRef.current = null;
      }
      return s;
    });
  }

  function handleHumanDraw() {
    if (state.gameOver || !currentPlayer.isHuman) return;
    setState((prev) => {
      const s: GameState = structuredClone(prev);
      drawForPlayer(s, 0);
      return s;
    });
  }

  function restart() {
    setState(initGame(3, 5));
    setSelectedColor(null);
    pendingCardRef.current = null;
  }

  const humanPlayable = human.hand.filter((c) =>
    canPlayCard(c, topCard, state.activeColor)
  );
  const humanCanPlay = humanPlayable.length > 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-950 p-4 md:p-8">
      <div className="mx-auto max-w-6xl space-y-6">
        {/* En-tête */}
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-emerald-700/40 bg-emerald-900/50 p-6 shadow-lg backdrop-blur">
          <div>
            <h1 className="font-serif text-3xl font-bold text-emerald-50">
              Jeu de Pêche
            </h1>
            <p className="text-sm text-emerald-300">
              Jouez contre 2 adversaires IA — 52 cartes, règles complètes
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Badge className="bg-emerald-700 text-emerald-50">
              Pioche : {state.drawStack.length}
            </Badge>
            <Badge className="bg-teal-700 text-teal-50">
              Dépôt : {state.depositStack.length}
            </Badge>
            <Badge className="bg-amber-600 text-amber-50">
              Sens : {state.direction}
            </Badge>
            <Button
              onClick={restart}
              variant="secondary"
              className="bg-emerald-50 text-emerald-900 hover:bg-white"
            >
              Rejouer
            </Button>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Zone de jeu principale */}
          <div className="space-y-6 lg:col-span-2">
            {/* Adversaires */}
            <div className="grid grid-cols-2 gap-4">
              {state.players.slice(1).map((p, i) => {
                const idx = i + 1;
                const isCurrent = state.currentPlayerIndex === idx;
                return (
                  <UICard
                    key={p.person.id}
                    className={cn(
                      "border-emerald-700/40 bg-emerald-900/40 text-emerald-50 transition-all",
                      isCurrent && "ring-2 ring-amber-400"
                    )}
                  >
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-center justify-between text-base">
                        <span>
                          {p.person.firstName} {p.person.lastName}
                        </span>
                        <Badge variant="secondary" className="bg-emerald-800 text-emerald-100">
                          {p.hand.length} cartes
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-1">
                        {p.hand.map((c) => (
                          <div
                            key={c.id}
                            className="flex h-10 w-7 items-center justify-center rounded border border-emerald-600/50 bg-emerald-800/60 text-xs font-bold text-emerald-100"
                          >
                            {c.value}
                          </div>
                        ))}
                      </div>
                      {p.hand.length === 1 && (
                        <p className="mt-2 text-xs font-semibold text-amber-300">
                          ⚠️ Plus qu'une carte !
                        </p>
                      )}
                    </CardContent>
                  </UICard>
                );
              })}
            </div>

            {/* Table centrale */}
            <UICard className="border-emerald-700/40 bg-emerald-900/40">
              <CardHeader>
                <CardTitle className="text-emerald-50">Table de jeu</CardTitle>
              </CardHeader>
              <CardContent className="flex items-center justify-center gap-8 py-8">
                <div className="flex flex-col items-center gap-2">
                  <span className="text-xs uppercase tracking-wide text-emerald-400">
                    Pioche
                  </span>
                  <div className="flex h-24 w-16 items-center justify-center rounded-lg border-2 border-dashed border-emerald-600 bg-emerald-800/40 text-emerald-300">
                    🂠
                  </div>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <span className="text-xs uppercase tracking-wide text-emerald-400">
                    Dépôt
                  </span>
                  {topCard ? (
                    <PlayingCard card={topCard} size="lg" />
                  ) : (
                    <div className="flex h-28 w-20 items-center justify-center rounded-lg border-2 border-dashed border-emerald-600 text-emerald-400">
                      Vide
                    </div>
                  )}
                  {state.activeColor && (
                    <span className="text-xs text-amber-300">
                      Couleur active : {COLOR_SYMBOL[state.activeColor]}{" "}
                      {state.activeColor}
                    </span>
                  )}
                </div>
              </CardContent>
            </UICard>

            {/* Main du joueur humain */}
            <UICard className="border-emerald-700/40 bg-emerald-900/40">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center justify-between text-emerald-50">
                  <span>
                    Votre main ({human.hand.length} cartes)
                    {currentPlayer.isHuman && (
                      <span className="ml-2 text-sm font-normal text-amber-300">
                        — à vous de jouer
                      </span>
                    )}
                  </span>
                  <Badge variant="secondary" className="bg-emerald-800 text-emerald-100">
                    {handPoints(human.hand)} pts
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {state.awaitingColorChoice ? (
                  <div className="space-y-3">
                    <p className="text-sm text-emerald-200">
                      Choisissez une couleur (Valet) :
                    </p>
                    <div className="flex gap-3">
                      {COLORS.map((color) => (
                        <Button
                          key={color}
                          onClick={() => confirmColor(color)}
                          className="bg-emerald-700 text-emerald-50 hover:bg-emerald-600"
                        >
                          {COLOR_SYMBOL[color]} {color}
                        </Button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {human.hand.map((c) => {
                      const playable = canPlayCard(c, topCard, state.activeColor);
                      return (
                        <PlayingCard
                          key={c.id}
                          card={c}
                          playable={playable && currentPlayer.isHuman}
                          disabled={!currentPlayer.isHuman || !playable}
                          onClick={() => handleHumanPlay(c)}
                        />
                      );
                    })}
                    {currentPlayer.isHuman && !humanCanPlay && (
                      <div className="flex items-center">
                        <Button
                          onClick={handleHumanDraw}
                          className="bg-amber-600 text-white hover:bg-amber-500"
                        >
                          Piocher une carte
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </UICard>
          </div>

          {/* Journal */}
          <UICard className="border-emerald-700/40 bg-emerald-900/40">
            <CardHeader>
              <CardTitle className="text-emerald-50">Journal de partie</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex max-h-96 flex-col gap-2 overflow-y-auto pr-1">
                {state.log
                  .slice()
                  .reverse()
                  .map((entry) => (
                    <div
                      key={entry.id}
                      className={cn(
                        "rounded-lg border px-3 py-2 text-xs",
                        entry.type === "play" &&
                          "border-emerald-600/40 bg-emerald-800/40 text-emerald-100",
                        entry.type === "attack" &&
                          "border-rose-500/40 bg-rose-900/30 text-rose-200",
                        entry.type === "draw" &&
                          "border-sky-500/40 bg-sky-900/30 text-sky-200",
                        entry.type === "win" &&
                          "border-amber-400/60 bg-amber-900/40 font-semibold text-amber-200",
                        entry.type === "system" &&
                          "border-slate-500/40 bg-slate-800/40 text-slate-300",
                        entry.type === "info" &&
                          "border-teal-500/40 bg-teal-900/30 text-teal-200"
                      )}
                    >
                      {entry.message}
                    </div>
                  ))}
              </div>
            </CardContent>
          </UICard>
        </div>

        {/* Fin de partie */}
        {state.gameOver && state.winner && (
          <UICard className="border-amber-400/60 bg-amber-900/40">
            <CardHeader>
              <CardTitle className="text-amber-100">
                🏆 Partie terminée — {state.winner.person.firstName}{" "}
                {state.winner.person.lastName} gagne !
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 sm:grid-cols-3">
                {state.players.map((p) => (
                  <div
                    key={p.person.id}
                    className="rounded-lg border border-amber-500/40 bg-amber-950/40 p-3 text-amber-100"
                  >
                    <p className="font-semibold">
                      {p.person.firstName} {p.person.lastName}
                    </p>
                    <p className="text-sm">
                      Cartes restantes : {p.hand.length} — Bilan : {p.score} pts
                    </p>
                  </div>
                ))}
              </div>
              <Button
                onClick={restart}
                className="mt-4 bg-amber-500 text-amber-950 hover:bg-amber-400"
              >
                Nouvelle partie
              </Button>
            </CardContent>
          </UICard>
        )}
      </div>
    </div>
  );
}