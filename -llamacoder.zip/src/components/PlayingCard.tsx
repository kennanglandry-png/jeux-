import { cn } from "@/lib/utils";
import type { Card } from "@/types/game";
import { COLOR_IS_RED, COLOR_SYMBOL } from "@/lib/gameLogic";

interface PlayingCardProps {
  card: Card;
  onClick?: () => void;
  disabled?: boolean;
  playable?: boolean;
  size?: "sm" | "md" | "lg";
}

export function PlayingCard({
  card,
  onClick,
  disabled,
  playable,
  size = "md",
}: PlayingCardProps) {
  const isRed = COLOR_IS_RED[card.color];
  const symbol = COLOR_SYMBOL[card.color];

  const sizeClasses = {
    sm: "w-12 h-16 text-xs",
    md: "w-16 h-24 text-sm",
    lg: "w-20 h-28 text-base",
  }[size];

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "relative flex flex-col items-center justify-between rounded-lg border bg-white p-1.5 shadow-sm transition-all",
        sizeClasses,
        isRed ? "text-rose-600" : "text-slate-900",
        playable && "ring-2 ring-emerald-500 hover:-translate-y-2 hover:shadow-md",
        !playable && disabled && "opacity-50",
        onClick && !disabled && "cursor-pointer hover:-translate-y-1 hover:shadow-md"
      )}
    >
      <span className="self-start font-bold leading-none">{card.value}</span>
      <span className="text-2xl leading-none">{symbol}</span>
      <span className="self-end rotate-180 font-bold leading-none">
        {card.value}
      </span>
    </button>
  );
}