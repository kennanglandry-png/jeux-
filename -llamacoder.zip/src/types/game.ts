// Types et concepts du domaine du jeu de cartes

export type CardColor = "Trèfle" | "Carreau" | "Cœur" | "Pique";

export type CardValue =
  | "As"
  | "2"
  | "3"
  | "4"
  | "5"
  | "6"
  | "7"
  | "8"
  | "9"
  | "10"
  | "Valet"
  | "Dame"
  | "Roi";

export interface Card {
  id: string;
  value: CardValue;
  color: CardColor;
  name: string;
}

export interface Person {
  id: string;
  firstName: string;
  lastName: string;
}

export interface Player {
  person: Person;
  hand: Card[];
  isHuman: boolean;
  score: number;
}

export type Direction = "horaire" | "anti-horaire";

export interface GameState {
  players: Player[];
  drawStack: Card[];
  depositStack: Card[];
  currentPlayerIndex: number;
  direction: Direction;
  pendingDraw: number;
  skipNext: boolean;
  activeColor: CardColor | null;
  winner: Player | null;
  log: LogEntry[];
  gameOver: boolean;
  awaitingColorChoice: boolean;
}

export interface LogEntry {
  id: string;
  message: string;
  type: "info" | "play" | "draw" | "attack" | "win" | "system";
}