#!/bin/bash
# create-class.sh

if [ -z "$1" ]; then
    echo "Usage: ./create-class.sh <NomClasse>"
    exit 1
fi

CLASS_NAME=$1

cat > "src/$CLASS_NAME.cs" << EOF
namespace JeuDePeche;

public class $CLASS_NAME
{
    // Propriétés
    // Constructeurs
    // Méthodes
}
EOF

echo "✅ Classe $CLASS_NAME créée"